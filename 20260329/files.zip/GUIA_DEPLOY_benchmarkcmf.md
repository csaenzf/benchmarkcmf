# Guía de Despliegue — benchmarkcmf.cl

## Arquitectura

```
[Usuario] → benchmarkcmf.cl
              ↓
        [Cloudflare Access]  ← Lista de emails autorizados
              ↓ (autenticado)
        [Cloudflare Pages]   ← HTML estático (gratis)
              ↓
        [CDN Global]         ← SSL automático
```

**Costo total: $0/mes** (Free tier de Cloudflare cubre todo)

---

## PASO 1 — Crear cuenta en Cloudflare

1. Ve a **https://dash.cloudflare.com/sign-up**
2. Crea cuenta con tu email (cristobal.saenzf@gmail.com)
3. Confirma el email

---

## PASO 2 — Agregar dominio benchmarkcmf.cl

1. En el dashboard de Cloudflare, click **"Add a site"**
2. Escribe: `benchmarkcmf.cl`
3. Selecciona el plan **Free**
4. Cloudflare escaneará los DNS existentes — click **Continue**
5. Cloudflare te dará **2 nameservers**, algo como:
   ```
   aria.ns.cloudflare.com
   leon.ns.cloudflare.com
   ```
6. **Anota estos nameservers** — los necesitas para el paso 3

---

## PASO 3 — Cambiar nameservers en NIC Chile

Esto depende de dónde compraste el dominio:

### Si compraste en nic.cl directamente:
1. Ve a **https://www.nic.cl** → Iniciar Sesión
2. Ve a **Mis Dominios** → `benchmarkcmf.cl`
3. Click en **Servidores DNS** → **Modificar**
4. Reemplaza los nameservers existentes por los de Cloudflare:
   ```
   aria.ns.cloudflare.com
   leon.ns.cloudflare.com
   ```
5. Guarda cambios

### Si compraste en un registrar (ej: GoDaddy, Namecheap):
1. Ve al panel de tu registrar
2. Busca la sección DNS/Nameservers del dominio
3. Cambia a los nameservers de Cloudflare
4. Guarda

**⏱ Propagación: 5 min a 24 horas** (típicamente 1-2 horas en Chile)

Vuelve a Cloudflare y click **"Check nameservers"**. Cuando detecte el cambio, el dominio quedará activo.

---

## PASO 4 — Crear proyecto en Cloudflare Pages

### Opción A: Subir directamente (más rápido)

1. En Cloudflare Dashboard → **Workers & Pages** → **Create**
2. Pestaña **Pages** → **Upload assets**
3. Nombre del proyecto: `benchmarkcmf`
4. Arrastra la carpeta `benchmarkcmf/` (que contiene `index.html`)
5. Click **Deploy site**
6. Cloudflare te dará una URL temporal tipo: `benchmarkcmf.pages.dev`
7. Verifica que funciona visitando esa URL

### Opción B: Conectar con GitHub (para futuras actualizaciones)

1. Crea un repositorio en GitHub: `benchmarkcmf`
2. Sube los archivos:
   ```bash
   cd benchmarkcmf
   git init
   git add .
   git commit -m "Dashboard CMF v1"
   git remote add origin https://github.com/TU_USUARIO/benchmarkcmf.git
   git push -u origin main
   ```
3. En Cloudflare → **Workers & Pages** → **Create**
4. Pestaña **Pages** → **Connect to Git**
5. Selecciona el repositorio `benchmarkcmf`
6. Framework preset: **None**
7. Build command: (dejar vacío)
8. Build output directory: `/` (o dejar vacío)
9. Click **Save and Deploy**

Cada vez que hagas `git push`, el sitio se actualiza automáticamente.

---

## PASO 5 — Conectar dominio personalizado

1. En Cloudflare Pages → tu proyecto `benchmarkcmf`
2. Pestaña **Custom domains**
3. Click **Set up a custom domain**
4. Escribe: `benchmarkcmf.cl`
5. Click **Continue** → Cloudflare creará el registro DNS automáticamente
6. También agrega: `www.benchmarkcmf.cl` (repite el proceso)
7. El SSL se activa automáticamente (puede tomar hasta 15 min)

**Resultado:** `https://benchmarkcmf.cl` funcionando con SSL ✅

---

## PASO 6 — Configurar Cloudflare Access (autenticación)

Este es el paso clave para controlar quién puede entrar.

### 6.1 Activar Zero Trust

1. En Cloudflare Dashboard → menú lateral → **Zero Trust**
2. Si es primera vez, te pide crear un "team name" (ej: `saenz-consulting`)
3. Selecciona plan **Free** (hasta 50 usuarios)

### 6.2 Crear política de acceso

1. En Zero Trust → **Access** → **Applications**
2. Click **Add an application**
3. Selecciona **Self-hosted**
4. Configuración:
   - **Application name:** `Benchmark CMF`
   - **Session Duration:** `24 hours` (o lo que prefieras)
   - **Application domain:**
     - Domain: `benchmarkcmf.cl`
     - Path: (dejar vacío para proteger todo el sitio)
   - También agregar: `www.benchmarkcmf.cl`
5. Click **Next**

### 6.3 Crear política con lista de emails

1. **Policy name:** `Usuarios Autorizados`
2. **Action:** `Allow`
3. En **Configure rules** → **Include**:
   - Selector: **Emails**
   - Value: agrega cada email autorizado, uno por uno:
     ```
     cristobal.saenzf@gmail.com
     mkt@chilelentes.cl
     cliente1@bancochile.cl
     cliente2@bancochile.cl
     ```

   **Alternativa por dominio:** Si todos los usuarios del cliente son @bancochile.cl:
   - Selector: **Email domain**
   - Value: `bancochile.cl`
   - Esto permite a CUALQUIER email @bancochile.cl entrar

4. Click **Next** → **Add application**

### 6.4 Resultado

Cuando alguien visite `benchmarkcmf.cl`:
1. Ve una pantalla de login de Cloudflare (profesional, con tu branding)
2. Ingresa su email
3. Si el email está en la lista autorizada, recibe un **código de 6 dígitos** por email
4. Ingresa el código → accede al dashboard
5. La sesión dura 24 horas (configurable)

Si el email **no** está en la lista → mensaje de "acceso denegado".

---

## PASO 7 — Personalizar pantalla de login (opcional)

1. En Zero Trust → **Settings** → **Authentication**
2. Pestaña **Login page**
3. Puedes personalizar:
   - **Background color:** `#0A0F1C`
   - **Header text:** `Benchmark CMF`
   - **Logo URL:** (sube un logo si tienes)
   - **Footer text:** `Acceso restringido — Solo usuarios autorizados`

---

## PASO 8 — Verificación final

Checklist de verificación:

- [ ] `https://benchmarkcmf.cl` carga la pantalla de login
- [ ] Ingresando un email autorizado, llega el código OTP
- [ ] Ingresando el código, se ve el dashboard
- [ ] Ingresando un email NO autorizado, se deniega acceso
- [ ] `https://www.benchmarkcmf.cl` también funciona (redirect)
- [ ] El certificado SSL está activo (candado verde)
- [ ] El dashboard se ve bien en móvil

---

## Gestión de usuarios

### Agregar un usuario nuevo:
1. Zero Trust → Access → Applications → `Benchmark CMF`
2. Click en la política `Usuarios Autorizados`
3. Agrega el email en la sección **Include**
4. Guarda

### Revocar acceso:
1. Elimina el email de la política
2. En Zero Trust → **Access** → **Logs**, puedes ver quién ha accedido
3. Para revocar sesiones activas: Zero Trust → **Users** → busca al usuario → **Revoke**

### Ver quién ha entrado:
1. Zero Trust → **Logs** → **Access**
2. Muestra: email, fecha, hora, IP, dispositivo

---

## Actualizar el dashboard

### Si usaste upload directo:
1. Cloudflare Pages → tu proyecto → **Create new deployment**
2. Sube la carpeta actualizada
3. Se publica instantáneamente

### Si usaste GitHub:
```bash
# Edita index.html con los nuevos datos
git add .
git commit -m "Actualización datos Enero 2026"
git push
# Se despliega automáticamente en ~30 segundos
```

---

## Estructura de archivos

```
benchmarkcmf/
└── index.html    ← Dashboard completo (archivo único, ~16KB)
```

Eso es todo. Un solo archivo HTML con todo embebido (CSS, JS, datos).
Las fonts se cargan desde Google Fonts CDN.

---

## Resumen de costos

| Servicio | Plan | Costo |
|----------|------|-------|
| Cloudflare | Free | $0/mes |
| Cloudflare Pages | Free | $0/mes |
| Cloudflare Access | Free (50 users) | $0/mes |
| Dominio .cl | - | ~$12.000 CLP/año |
| **Total** | | **~$12.000 CLP/año** |

---

## Soporte

- Cloudflare Docs: https://developers.cloudflare.com/pages/
- Cloudflare Access: https://developers.cloudflare.com/cloudflare-one/applications/
- NIC Chile: https://www.nic.cl/
